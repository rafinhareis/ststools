from .base import Display,Save_data,Hist_plot,Grid_plot,Open_files,Hist_metal,Hist_molecule

print('Software de visualizacao de arquivos de STS Nanosurf e Omicron v1.0.1')
print('By Rafael Reis Barreto, contato rafinhareis17@gmail.com')
print('Arquivos Nanosurf tipo csv (x,y,z) ')
print('Aquivos Omicron tipo .txt ou .asc para grid. NAO MUDAR O NOME DO ARQUIVO PADRAO')
print('Se sentir no fundo do coracaozinho, poe meu nome no artigo =D')


