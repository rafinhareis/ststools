from .base import Display,Map

print('Software de visualizacao de arquivos de STS Nanosurf e Omicron v6.6.0')
print('By Rafael Reis Barreto, contato rafinhareis17@gmail.com')
print('Github com o codigo fonte https://github.com/rafinhareis/ststools')
print('Repositorio Pypi https://pypi.org/project/ststools/ (nele voce pode conferir qual a versao mais atual)')
print('Arquivos Nanosurf tipo .nid ')
print('Aquivos Omicron tipo .txt, ou .ibw (IGOR) para grid. NAO MUDAR O NOME DO ARQUIVO PADRAO')
print('Arquivos Nanonis tipo .dat ')
print('Se sentir no fundo do coracaozinho, poe meu nome no artigo =D')


